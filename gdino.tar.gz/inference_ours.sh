python inference_ours.py \
  -c tools/CLIPGroundingDINO.py \
  -p /data_hdd/zhouzizheng/clip_test/checkpoint.pth \
  -i /data_hdd/zhouzizheng/data/DetectEverything2/DOGE_202207071613_930.JPEG \
  -o output \
  -r /data_hdd/zhouzizheng/data/DetectEverything2/DOGE_202207071613_930.JPEG \
  -t "DOGE" 